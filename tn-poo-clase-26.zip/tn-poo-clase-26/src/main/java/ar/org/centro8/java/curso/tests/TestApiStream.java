package ar.org.centro8.java.curso.tests;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import ar.org.centro8.java.curso.entidades.colecciones.Persona;

public class TestApiStream {
    public static void main(String[] args) {
        //API Stream (Java 8)
        /*
         * Permite procesar flujos de datos de manera uniforme, independientemente de la fuente
         * de datos (archivo, BD, web service, etc.) utilizando un enfoque declarativo con expresiones
         * lambda.
         * API (Application Programming Interface) es un conjunto de métodos e interfaces que facilitan
         * el acceso a funcionalidades sin conocer su implementación interna.
         * Podemos decir que una API es como un conjunto de reglas y herramientas que permite que dos
         * programas se comuniquen entre sí.
         */

        //creamos una lista de Persona
        List<Persona> personas = new ArrayList<>();
        
        //agregamos elementos a la lista
        personas.add(new Persona(1, "Ana", 32));
        personas.add(new Persona(2, "Javier", 41));
        personas.add(new Persona(3, "Carlos", 22));
        personas.add(new Persona(4, "Estela", 55));
        personas.add(new Persona(5, "Raul", 27));
        personas.add(new Persona(6, "Miguel", 37));
        personas.add(new Persona(7, "Monica", 47));
        personas.add(new Persona(8, "Marcela", 57));
        personas.add(new Persona(9, "Ricardo", 67));
        personas.add(new Persona(10, "Juan", 45));
        personas.add(new Persona(11, "Juan", 23));

        //select * from personas;
        System.out.println("\n-- select * from personas;--");
        personas.forEach(System.out::println);

        //Stream provee métodos para filtrar
        //el método stream() devuelve una implementación de la interface Stream
        //el método filter() permite sobreescribir un predicado de expresión lambda
        //un predicado es una interface funcional que define una condición que un objeto determinado
        //debe cumplir.

        System.out.println("\n-- select * from personas where nombre='Ana'; --");
        personas
                .stream() //devuelve una secuencia de elementos para procesarlos (no guarda los elementos)
                .filter(p->p.getNombre().equals("Ana")) //obtenemos un objeto del tipo Persona, luego 
                //va la expresión booleana. Si arroja true, es parte de los resultados, 
                //si arroja false, no es parte de los resultados.
                .forEach(System.out::println); //filter devuelve un stream con todos los registros
                //con foreach() los recorremos.

        System.out.println("\n-- select * from personas where nombre='Ana' or nombre='Juan'; --");
        personas
                .stream()
                .filter(p->p.getNombre().equals("Ana") || p.getNombre().equals("Juan"))
                .forEach(System.out::println);

        System.out.println("\n-- select * from personas where nombre like 'ja%'; --");
        personas
                .stream()
                .filter(p->p.getNombre().toLowerCase().startsWith("ja"))
                .forEach(System.out::println);

        System.out.println("\n-- select * from personas where nombre like '%a'; --");
        personas
                .stream()
                .filter(p->p.getNombre().toLowerCase().endsWith("a"))
                .forEach(System.out::println);

        System.out.println("\n-- select * from personas where nombre like '%ar%'; --");
        personas
                .stream()
                .filter(p->p.getNombre().toLowerCase().contains("ar"))
                .forEach(System.out::println);

        System.out.println("\n-- select * from personas where edad >= 30; --");
        personas
                .stream()
                .filter(p->p.getEdad()>=30)
                .forEach(System.out::println);

        System.out.println("\n-- select * from personas where nombre='Juan' and edad >=30; --");
        personas
                .stream()
                .filter(p->p.getNombre().equals("Juan") && p.getEdad()>=30)
                .forEach(System.out::println);
        
        System.out.println("\n-- select * from personas order by nombre; --");
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getNombre))
                .forEach(System.out::println);
        //el método sorted() ordena
        //si lo utilizamos solo, sin parámetros, la clase debe implementar la interfaz Comparable
        //No termina siendo una solución flexible ya que si tuviésemos que cambiar el ordenamiento
        //tendríamos que modificar el método compareTo() de la clase.
        //La interfaz Comparator permite definir criterios de comparación entre objetos, es decir,
        //especifica cómo se debe ordenar un conjunto de elementos. No se trata de ordenarlos según
        //el orden natural de los objetos, sino de definir un criterio personalizado para compararlos.
        
        System.out.println("\n-- select * from personas order by edad; --");
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getEdad))
                .forEach(System.out::println);

        System.out.println("\n-- select * from personas order by nombre, edad; --");
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getNombre)
                .thenComparing(Persona::getEdad))
                .forEach(System.out::println);
        //thenComparing() se utiliza para definir criterios de ordenamiento adicionales

        System.out.println("\n-- select * from personas order by nombre desc, edad; --");
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getNombre)
                .reversed() //invierte el criterio de ordenamiento
                .thenComparing(Comparator.comparing(Persona::getEdad)))
                .forEach(System.out::println);

        System.out.println("\n-- select * from personas order by id; --");
        personas
                .stream()
                .sorted(Comparator.comparingInt(Persona::getId))
                .forEach(System.out::println);
        //comparingInt() trabaja directamente con enteros, lo que hace que se mejore la performance

        System.out.println("\n- select * from personas where edad between 30 and 40 order by nombre desc; --");
        personas
                .stream()
                .filter(p->p.getEdad()>=30 && p.getEdad()<=40)
                .sorted(Comparator.comparing(Persona::getNombre)
                .reversed())
                .forEach(System.out::println);

        System.out.println("\n-- select max(edad) from personas; --");
        //System.out.println(
        int maxEdad = 
            personas
                    .stream()
                    .max(Comparator.comparingInt(Persona::getEdad))
                    .get()
                    .getEdad(); //);
        System.out.println(maxEdad);
        //el método max() devuelve un objeto de Optional, no devuelve una lista, contiene una 
        //persona con la mayor edad. Con .get() obtenemos el valor del objeto Optional, o sea,
        //un objeto de la clase Persona. Con .getEdad() obtenemos la edad del objeto del tipo Persona

        System.out.println("\n-- select * from personas where edad=(select max(edad) from personas); --");
        personas
                .stream()
                .filter(p->p.getEdad()==(
                    personas
                            .stream()
                            .max(Comparator.comparingInt(Persona::getEdad))
                            .get()
                            .getEdad()  
                ))
                .forEach(System.out::println);
        //esta solución no es performante, ya que en cada iteración vuelve a calcular la subconsulta

        System.out.println("\n-- misma query pero simplificando código --");
        personas
                .stream()
                .filter(p->p.getEdad()==maxEdad)
                .forEach(System.out::println);


    }
}
