package ar.org.centro8.java.curso.tests;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class TestMaps {
    public static void main(String[] args) {
        //Interface Map
        /*
         * La interface Map permite representar un diccionario o una estructura de datos de pares
         * clave-valor. En un Map, cada clave (key) se asocia a un valor (value). Las claves no
         * tienen por qué ser siempre números ni consecutivas. Pueden ser de cualquier tipo de
         * objeto (por ejemplo String, Integer, etc.). Esto permite representar relaciones o 
         * asociaciones en las que el índice es una clave arbitraria.
         * Un Map no extiende de Collection. 
         * Sí, forma parte del framework Collections, es una interfaz aparte.
         * Cada clave es única dentro del mapa, si se agrega un valor con una clave que ya existe,
         * se reemplaza el valor anterior.
         * A partir del JDK 8, Map incorpora un método foreach que recibe un BiConsumer (una expresión
         * Lambda que acepta la clave y el valor) para recorrer de forma automática todos sus pares.
         */

        System.out.println("** Interface Map **");

        Map<String, String> mapaSemana;
        //K y V son key y value, es decir, llave y valor
        //El primero es la K y el segundo es el V
        //En este caso la clase String es tanto llave, como valor.
        //No se pueden declarar ni llaves ni valores de tipos de datos primitivos, debemos utilizar
        //los wrappers.

        //implementaciones de Map

        //HashMap: implementa un mapa sin ningún orden garantizado. Es una de las implementaciones 
        //más eficientes para operaciones de inserción y búsqueda.
        mapaSemana = new HashMap<>();

        //LinkedHashMap: mantiene el orden de inserción, lo que permite recorrer el mapa en el orden
        //en que se agregaron los elementos
        mapaSemana = new LinkedHashMap<>();

        //TreeMap: implementa NavigableMap que implementa SortedMap. Ordena las claves según su orden
        //natural o mediante un Comparator. Para ello, requiere que las claves implementen la interfaz
        //Comparable, similar a como funciona TreeSet.
        mapaSemana = new TreeMap<>();

        //HashTable: es una clase legacy (de legado) que implementa la interfaz Map, similar a 
        //HashMap, y su orden es aleatorio. No está deprecada, pero su uso no es recomendado en
        //proyectos nuevos. Sus métodos son sincronizados, lo que la hace thread-safe, pero a costa
        //de menos performance en comparación con HashMap. Se mantiene para dar soporte a proyectos
        //antiguos, aunque en desarrollo moderno se prefiere utilizar HashMap o ConcurrentHashMap
        mapaSemana = new Hashtable<>();

        //con el método .put() agrego un elemento
        mapaSemana.put("lu", "lunes");
        mapaSemana.put("ma", "martes");
        mapaSemana.put("mi", "miércoles");
        mapaSemana.put("ju", "jueves");
        mapaSemana.put("vi", "viernes");
        mapaSemana.put("sa", "sábado");
        mapaSemana.put("do", "domingo");
        //se puede repetir los valores, pero no las llaves.

        System.out.println("\n-- recorrido de mapaSemana --");
        mapaSemana.forEach((k,v) -> System.out.println(k + " -> " + v));

        System.out.println("\n&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n");
        //remove() elimina un elemento pasando la llave (key)
        mapaSemana.remove("vi");
        mapaSemana.forEach((k,v) -> System.out.println(k + " -> " + v));

    }
}
