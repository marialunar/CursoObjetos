package ar.org.centro8.java.curso.tests;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import ar.org.centro8.java.curso.entidades.colecciones.Auto;

public class TestCollections {
    public static void main(String[] args) {
        /*
         * La interfaz List representa una lista con índices.
         * Es la única que tiene métodos con índices.
         * De esta interfaz, se pueden elegir distintas implementaciones con distintas tecnologías.
         * ArrayList es una lista del tipo vector, que tiene dentro un comportamiento que emula
         * a un Array, pero que no es un Array, ya que es completamente dinámico.
         * LinkedList tiene todo el comportamiento heredado de List, pero internamente, utiliza una
         * lista enlazada.
         * La clase Vector, implementa List, pero no son los vectores que hemos visto anteriormente.
         * Es una colección que internamente utiliza tecnología de vectores, pero que ha quedado en
         * desuso, es un lenguaje antiguo, con tecnología antigua, tiene una sincronización excesiva,
         * lo que la hace muy lento. Por eso se recomienda no utilizarla.
         * ArrayList es una lista del tipo Array y LinkedList es una lista enlazada.
         * ArrayList es más veloz para recorrer elementos.
         * LinkedList es más veloz para agregar y eliminar elementos.
         */

        //declaramos una variable del tipo de la interfaz para hacer polimorfismo
        List lista;

        lista = new ArrayList<>();

        // .add() método para agregar elementos a la lista
        lista.add(new Auto("Ford", "Focus", "Celeste fuego"));
        lista.add(new Auto("Peugeot", "308", "Gris perlado"));
        lista.add("Hola");
        lista.add(80);
        lista.add(23.45);
        //esta lista no tiene especificado un tipo de dato en particular
        //por lo tanto, será por defecto, del tipo Object, esto quiere decir que podrá guardar
        //cualquier tipo de dato.

        //recorrido de la lista con índices
        System.out.println("** Recorrido por índices **");
        for (int i = 0; i < lista.size(); i++) { //el método size() indica la longitud
            System.out.println(lista.get(i));
            //el método get() obtiene el elemento de la posición que se pasó como parámetro
        }

        // .remove() método para eliminar un elemento
        lista.remove(3); //elimina el elemento del índice 3

        //recorremos la lista con un for-each
        System.out.println("\n-- Recorrido con for-each --");
        for(Object o:lista) System.out.println(o);
        //el for-each funciona tanto con Arrays como con colecciones que implementen la interfaz Iterable
        //No sirve para agregar o eliminar elementos durante la iteración
        //No tiene acceso a los índices

        /*
         * Interfaz Iterable
         * Iterable es la interfaz padre de todas las interfaces del framework Collections.
         * Dentro de Iterable, se encuentra definido el método foreach(), es un método default.
         * Este método realiza un recorrido, facilita el recorrido de las colecciones sin utilizar
         * una estructura de repetición. Es la misma lista la que se autorecorre. Es una forma de
         * escribir código mucho más compacta, simple y moderna. Aparece a partir del JDK 8.
         */

        System.out.println("\n-- Recorrido con método foreach() --");

        lista.forEach(item -> System.out.println(item));
        /*
        el método foreach() recibe una expresión del tipo Consumer que define qué operación
        se ejecutará sobre cada elemento de la colección.
        Consumer es una interfaz funcional, cuyo propósito es "consumir" un valor (tiene un 
        único método abstracto). Representa una operación que recibe un argumento del tipo T y no
        devuelve nada. T es un tipo de dato genérico, no es un tipo concreto.
        Generalmente, se utilizan expresiones Lambdas.
        Las Lambda Expression son funciones anónimas que aparecieron a partir del JDK 8.
        Una función anónima es una porción de código (una función) que no tiene nombre y se define
        en el sitio en donde se va a utilizar.
        Se utilizan para simplificar código.
        En este caso, por cada elemento de la lista, voy a tener una variable llamada "item".
        No necesitamos indicar de qué tipo de dato es la lista.
        Luego va el operador flecha y la sentencia que se va a ejecutar por cada elemento.
        El operador flecha pertenece específicamente a las expresiones lambdas, separa los 
        parámetros del cuerpo de una función anónima.
        */

        System.out.println();

        //si quisiéramos definir más de una sentencia tenemos que utilizar un bloque de llaves
        lista.forEach(item -> {
            System.out.println(item);
            System.out.println("-");
        });

        // referencia de métodos (Method references)
        System.out.println("\n -- Recorrido con foreach() simplificado");
        lista.forEach(System.out::println);
        //con el operador de :: le estamos indicando que el ítem es implícito
        //y que lo coloque como argumento del método
        //es una sintaxis moderna, prolija y abreviada.

        System.out.println("\n** ListIterator **");
        /*
         * ListIterator es una interfaz especializada en recorrer colecciones que implementen List.
         * A diferencia del iterador simple (Iterator) o del método foreach() de Iterable, ListIterator
         * ofrece funcionalidades adicionales:
         * - recorrido bidireccional: permite avanzar y retroceder sobre las listas
         * - tiene acceso a índices
         * - permite eliminar, reemplazar y agregar elementos durante la ejecución.
         */

        List nombres = new ArrayList<>();
        nombres.add("Ricardo");
        nombres.add("Jenny");
        nombres.add("Carlos");
        nombres.add("Ana");
        nombres.add("Marcelo");

        //obtenemos el ListIterator
        ListIterator<String> li = nombres.listIterator();

        






    }
}
