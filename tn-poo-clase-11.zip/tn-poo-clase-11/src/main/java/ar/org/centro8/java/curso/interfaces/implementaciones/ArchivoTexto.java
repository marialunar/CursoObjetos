package ar.org.centro8.java.curso.interfaces.implementaciones;

import ar.org.centro8.java.curso.interfaces.IArchivo;

public class ArchivoTexto implements IArchivo {
    //La clase está obligada a sobreescribir los métodos abstractos.
    //La clase puede heredar de otra clase (extends + nombre de la clase padre).
    //La clase puede implementar varias interfaces (se separan los nombres con coma).
    //Si una clase implemeta múltiples interfaces que contengan un método default con la misma
    //firma, la clase debe sobreescribir ese método para resolver la ambigüedad.
    
    private String texto;

    @Override
    public void setText(String texto) {
        System.out.printf("Guardando '%s' dentro de archivo de texto\n", texto);
        this.texto = texto;
    }

    @Override
    public String getText() {
        return this.texto;
    }

    @Override
    public String getTipo() {
        return "Archivo de texto";
    }
}
