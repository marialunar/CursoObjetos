package ar.org.centro8.java.curso.tests;

import ar.org.centro8.java.curso.entidades.relaciones.Cuenta;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.ClientePersona;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.Direccion;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.Empleado;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.Persona;

public class TestHerencia {
    public static void main(String[] args) {
        /*
         * Herencia
         * Es un mecanismo para reutilizar miembros de una clase.
         * Esto favorece la extensión y especialización de comportamientos.
         * Representa la relación más fuerte entre clases.
         * La reconocemos con las palabras "es un/a".
         * En este caso, las clases pueden derivar de otras clases.
         * La clase derivada es una subclase y la clase de la que deriva es una superclase.
         * También se las conoce como clases hijas y clase padre.
         * Una clase en Java solo puede tener una única superclase directa.
         * Java no soporta la herencia múltiple.
         */

        System.out.println("** Test de la clase Direccion **");
        Direccion direccion1 = new Direccion("Av. Rivadavia", 18842, "1", "A", "Morón");
        System.out.println(direccion1);
        Direccion direccion2 = new Direccion("Av. Lascano", 13255, "PB", "C");
        System.out.println(direccion2);

        /* System.out.println("** Test de la clase Persona **");
        Persona persona1 = new Persona("Federico", "Nuñez", 30, direccion1);
        System.out.println(persona1);
        persona1.saludar(); */

        System.out.println("\n** Test de la clase Empleado **");
        Empleado empleado1 = new Empleado("Mariano", "Gimenez", 40, direccion1, 10, 500000);
        System.out.println(empleado1);
        empleado1.saludar();
        empleado1.comer();

        System.out.println("\n** Test de la clase ClientePersona **");
        Cuenta cuenta1 = new Cuenta(20, "Pesos argentinos");
        ClientePersona cliente1 = new ClientePersona("Gabriel", "Mendez", 33, direccion2, 110, cuenta1);
        System.out.println(cliente1);
        cliente1.saludar();
        cliente1.comer();

        //////////////////////////////////////////////////////////////////////////
        
        System.out.println("\n ** Polimorfismo **");

        /*
         * El polimorfismo es la capacidad de un objeto o método para tomar muchas formas.
         * Lo que permite que el mismo método pueda comportarse de diferentes maneras, dependiendo
         * del contexto.
         * 
         * Hay dos clases de polimorfismo:
         * 
         * Polimorfismo sin redefinición, es en tiempo de compilación (sobrecarga de métodos):
         *  Se produce cuando en una misma clase, existen varios métodos con el mismo nombre pero
         *  con diferentes parámetros (diferentes firmas). Esto permite ejecutar acciones similares
         *  sobre distintos tipos o números de argumentos.
         * 
         * Polimorfismo con redefinición, es en tiempo de ejecución (sobreescritura de métodos):
         *  Se produce cuando una subclase redefine un método heredado de la superclase (utilizando 
         * Override).
         *  Esto permite que una variable de tipo de la superclase pueda referenciar objetos de 
         *  diferentes subclases, comportándose de manera distinta según la instancia correcta.
         */

        /*
         * Persona es una clase abstracta, por lo cual no se pueden crear objetos de esa clase.
         * Lo que si se puede hacer es crear una variable de referencia de Persona.
         * Utilizamos para eso los constructores de las clases hijas.
         * Porque dentro de la variable del tipo Persona se pueden almacenar objetos de las clases hijas.
         */

        Persona persona1 = new Empleado("Ariel", "Martinez", 41, direccion2, 564, 1000000);
        Persona persona2 = new ClientePersona("Marcos", "Ponce", 100, direccion2, 2000, new Cuenta(120, "Yen"));

        //esto es un polimorfismo con redefinición, ya que el mismo método tiene distintos comportamientos
        persona1.saludar();
        persona2.saludar();

        //modificar el ejercicio de las figuras para que cumpla con el concepto de herencia.

        
    }
}
