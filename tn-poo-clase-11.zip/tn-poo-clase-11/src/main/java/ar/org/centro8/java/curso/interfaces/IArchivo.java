package ar.org.centro8.java.curso.interfaces;

public interface IArchivo {
    /*
     * Interfaces
     * - No tienen constructores, ya que no se pueden crear objetos de una interfaz.
     * - Todas las variables que se declaren en una interfaz son public static final
     * - Por defecto, los métodos de una interfaz son públicos. A partir del JDK 9 se pueden
     * definir métodos privados para uso interno. 
     * - Los métodos son por defecto abstractos, por lo que no tienen cuerpo o implementación.
     * - Las clases que implementen la interfaz están obligadas a darle comportamiento a todos
     * los métodos abstractos de la interfaz.
     * - A partir del JDK 8 aparecen los métodos default, son métodos que sí tienen cuerpo.
     * - La implementación de estos métodos default será compartida por todas las clases que
     * implementen la interfaz. Y podrán modificar el comportamiento si es que alguna necesita
     * una implementación específica.
     * - Una clase puede implementar todas las interfaces que desee.
     * - Al poder implementar varias interfaces, se da un comportamiento similar a lo que sería
     * una herencia múltiple que no existe en Java.
     * - Lo que se hereda son las firmas de los métodos (y las implementaciones de los métodos 
     * default, si los hubiera), lo que permite a la clase poder combinar comportamientos de 
     * distintas fuentes.
     */

    /**
     * Método para escribir un archivo
     * @param texto -> es el texto a escribir en el archivo
     */
    void setText(String texto); //no hace falta agregar public y abstract

    /**
     * Método para leer un archivo
     * @return -> retorna el texto del archivo
     */
    String getText();

    /**
     * Método que retorna en forma de cadena el tipo del archivo.
     * @return
     */
    String getTipo();

    /**
     * Método default que describe a la interfaz
     */
    default void info(){
        System.out.println("IArchivo: Interfaz para la gestión de archivos.\nDefine el comportamiento común para tosas las implementaciones");
    }


}
