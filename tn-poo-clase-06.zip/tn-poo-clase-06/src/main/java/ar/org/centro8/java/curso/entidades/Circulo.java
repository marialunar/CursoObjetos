package ar.org.centro8.java.curso.entidades;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Circulo {
    private double radio;

    public double getPerimetro(){
        return Math.PI * (radio * 2);
    }

    public double getSuperficie(){
        return Math.PI * radio * radio;
    }
}
