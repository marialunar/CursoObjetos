package ar.org.centro8.java.curso.tests;

import ar.org.centro8.java.curso.entidades.Circulo;
import ar.org.centro8.java.curso.entidades.Rectangulo;
import ar.org.centro8.java.curso.entidades.TrianguloRectangulo;

public class TestFiguras {
    public static void main(String[] args) {
        Rectangulo rectangulo1 = new Rectangulo(123.23, 15);
        System.out.println("El perímetro es: " + rectangulo1.getPerimetro());
        System.out.println("La superficie es: " + rectangulo1.getSuperficie());

        TrianguloRectangulo triangulo1 = new TrianguloRectangulo(158, 12.58);
        System.out.println("El perímetro es: " + triangulo1.getPerimetro());
        System.out.println("La superficie es: " + triangulo1.getSuperficie());

        Circulo circulo1 = new Circulo(12);
        System.out.println("El perímetro es: " + circulo1.getPerimetro());
        System.out.println("La superficie es: " + circulo1.getSuperficie());

    }
}
