package ar.org.centro8.java.curso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TnPooClase14Application {

	public static void main(String[] args) {
		SpringApplication.run(TnPooClase14Application.class, args);
	}

}
