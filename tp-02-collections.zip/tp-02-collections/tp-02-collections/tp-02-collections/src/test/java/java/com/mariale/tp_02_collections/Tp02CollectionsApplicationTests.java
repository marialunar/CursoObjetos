package java.com.mariale.tp_02_collections;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp02CollectionsApplicationTests {

	@Test
	void contextLoads() {
	}

}
