package ar.org.centro8.java.curso.tests;

import ar.org.centro8.java.curso.entidades.relaciones.herencia.Direccion;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.Persona;

public class TestHerencia {
    public static void main(String[] args) {
        /*
         * Herencia
         * Es un mecanismo para reutilizar miembros de una clase.
         * Esto favorece la extensión y especialización de comportamientos.
         * Representa la relación más fuerte entre clases.
         * La reconocemos con las palabras "es un/a".
         * En este caso, las clases pueden derivar de otras clases.
         * La clase derivada es una subclase y la clase de la que deriva es una superclase.
         * También se las conoce como clases hijas y clase padre.
         * Una clase en Java solo puede tener una única superclase directa.
         * Java no soporta la herencia múltiple.
         */

        System.out.println("** Test de la clase Direccion **");
        Direccion direccion1 = new Direccion("Av. Rivadavia", 18842, "1", "A", "Morón");
        System.out.println(direccion1);
        Direccion direccion2 = new Direccion("Av. Lascano", 13255, "PB", "C");
        System.out.println(direccion2);

        /* System.out.println("** Test de la clase Persona **");
        Persona persona1 = new Persona("Federico", "Nuñez", 30, direccion1);
        System.out.println(persona1);
        persona1.saludar(); */

        

    }
}
