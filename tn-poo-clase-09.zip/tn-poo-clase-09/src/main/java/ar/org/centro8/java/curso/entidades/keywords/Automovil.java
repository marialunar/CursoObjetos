package ar.org.centro8.java.curso.entidades.keywords;

import lombok.RequiredArgsConstructor;
import lombok.ToString;

@RequiredArgsConstructor
@ToString
public class Automovil {
    private final String marca;
    private final String modelo;
    private final String color;
    private static int velocidad;

    /*
     * final
     * Cuando una variable o atributo es declarado como final, queda constante. 
     * No se puede modificar su valor.
     * La keyword (palabra reservada) final a nivel atributo o variable determina que la misma
     * será siempre constante.
     * A nivel clase, la keyword final indica que esa clase no puede tener clases hijas.
     */

    /*
     * static
     * Un atributo es estático pertenece a la clase, no a los objetos.
     * Su estado es compartido por todas las instancias de la clase, ya que solo existe una copia.
     * Se accede a un atributo estático directamente a través del nombre de la clase.
     * Cuando un método es estático, significa que ese método pertenece a la clase.
     * Si el atributo que se modifica es estático, el método debe ser estático.
     * No podemos utilizar el this. porque hace referencia al objeto, y en un método estático,
     * no existe contexto de instancia (el método pertenece a la clase, no a un objeto).
     */

    public static int getVelocidad(){
        return velocidad;
    }

    public static void acelerar(int kilometros){
        velocidad += kilometros;
    }

    public static void frenar(int kilometros){
        if(velocidad-kilometros<0) velocidad=0;
        else velocidad-=kilometros;
    }
    //desde un método estático, solo se puede hacer referencia a atributos estáticos de la clase
    //desde un método no estático, se puede llamar a miembros estáticos y no estáticos.

}
