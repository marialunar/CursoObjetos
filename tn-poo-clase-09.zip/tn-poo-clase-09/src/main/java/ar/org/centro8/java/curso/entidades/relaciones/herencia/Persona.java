package ar.org.centro8.java.curso.entidades.relaciones.herencia;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public abstract class Persona {
    //la palabra reservada abstract indica que la clase es abstacta
    //no se pueden crear objetos de una clase abstracta
    //las clases abstractas sirven como modelo o plantilla para otras clases
    private String nombre;
    private String apellido;
    private int edad;
    private Direccion direccion;

    // public void saludar(){
    //     System.out.println("Hola, soy una persona!");
    // }

    public abstract void saludar();
    //un método abstracto no tiene implementación, es decir, no tiene un cuerpo.
    //las subclases deben implementar los métodos abstractos

    public void comer(){
        System.out.println("Estoy comiendo...");
    }
}
