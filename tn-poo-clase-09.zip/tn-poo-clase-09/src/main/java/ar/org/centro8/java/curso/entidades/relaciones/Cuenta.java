package ar.org.centro8.java.curso.entidades.relaciones;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Getter
@RequiredArgsConstructor
@ToString
public class Cuenta {
    private final int nro;
    private final String moneda;
    private float saldo; //inicializa en 0.0 por ser del tipo primitivo

    public void depositar(float monto){
        saldo += monto;
    }

    public void debitar(float monto){
        if(saldo-monto<0) System.out.println("Saldos insuficientes para realiza esta operación");
        else saldo -= monto;
    }
    
}
