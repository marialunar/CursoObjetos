package ar.org.centro8.java.curso.entidades.relaciones;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class ClienteMayorista {
    private int nro;
    private String razonSocial;
    private String direccion;
    private List<Cuenta> cuentas;
    //no utilizamos arrays porque son estáticos e inmutables.
    //Es decir, que se crearía una cantidad fija de cuentas y no se podría modificar.
    //Para este caso, necesitamos una lista dinámica, por eso utilizamos List. 
    //Es una herramienta más moderna.
    
    public ClienteMayorista(int nro, String razonSocial, String direccion) {
        this.nro = nro;
        this.razonSocial = razonSocial;
        this.direccion = direccion;
        this.cuentas = new ArrayList<>(); //ArrayList es una implementación de List
    }

    

}
