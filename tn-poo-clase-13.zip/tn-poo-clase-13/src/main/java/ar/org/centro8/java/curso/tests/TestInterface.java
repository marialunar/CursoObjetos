package ar.org.centro8.java.curso.tests;

import java.util.Scanner;

import ar.org.centro8.java.curso.interfaces.IArchivo;

public class TestInterface {
    public static void main(String[] args) {
        //creamos una referencia a la interfaz
        IArchivo archivo;

        Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese una oración:");
        String mensaje = teclado.nextLine();
        System.out.println("En qué tipo de archivo quiere guardar su texto?");
        System.out.println("BINARIO - TEXTO - NUBE");
        String opcion = teclado.nextLine();
        teclado.close();
        //en programas pequeños o en contextos de enseñanza, cerrar el Scanner no es crítico.
        //Pero en aplicaciones más grandes o reales, es una buena práctica para liberar recursos.

        //incialización
        archivo = IArchivo.crearArchivo(opcion);

        archivo.setText(mensaje);
        archivo.info();
        System.out.println(archivo.getTipo());
        System.out.println("Texto guardado -> " + archivo.getText());
    }
}
