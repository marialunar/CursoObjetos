package ar.org.centro8.java.curso.ejercicios.interfaces.implementaciones;

import ar.org.centro8.java.curso.ejercicios.interfaces.IPagos;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class Servicio implements IPagos{
    private String descripcion;
    private double tarifa;

    @Override
    public void pagarConTarjetaDebito(double monto) {
        // acá debería ir todo el proceso y tecnología para el pago con tarjeta de débito
        System.out.println("Se realizó el pago con tarjeta de débito");
    }

    @Override
    public void pagarConTarjetaCredito(double monto) {
        // acá debería ir todo el proceso y tecnología para el pago con tarjeta de crédito
        System.out.println("Se realizó el pago con tarjeta de crédito");
    }

    @Override
    public void pagarConTransferencia(double monto) {
        // acá debería ir todo el proceso y tecnología para el pago con transferencia
        System.out.println("Se realizó el pago con transferencia");
    }

    @Override
    public void pagarConEfectivo(double monto) {
        // acá debería ir todo el proceso y tecnología para el pago con efectivo
        System.out.println("Se genera un descuento del 10%");
        System.out.println("Monto cobrado = " + montoFormateado(aplicarDescuento(monto, 10)));
        System.out.println("Se realizó el pago con efectivo");
    }

    @Override
    public void pagarConQR(double monto) {
        // acá debería ir todo el proceso y tecnología para el pago con QR
        System.out.println("Se realizó el pago con QR");
    }
}
