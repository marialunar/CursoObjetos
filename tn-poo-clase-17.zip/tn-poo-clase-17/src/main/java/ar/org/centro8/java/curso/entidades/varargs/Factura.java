package ar.org.centro8.java.curso.entidades.varargs;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class Factura {
    private int numero;
}
