-- DROP DATABASE IF EXISTS regalos_einsof; 
-- CREATE DATABASE regalos_einsof;
-- USE regalos_einsof;

DROP TABLE IF EXISTS proveedores;
DROP TABLE IF EXISTS productos;
DROP TABLE IF EXISTS clientes;           
DROP TABLE IF EXISTS detalle_venta;
DROP TABLE IF EXISTS venta;

CREATE TABLE proveedores (
    proveedor_id INT PRIMARY KEY AUTO_INCREMENT,
    nombre_proveedor VARCHAR(100) NOT NULL,
    telefono VARCHAR(20)
);

CREATE TABLE clientes (
    cliente_id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50),
    dni CHAR(8) NOT NULL,
    cuit CHAR(11) NOT NULL,
    direccion VARCHAR(255) NULL,
    telefono VARCHAR(20)
);

CREATE TABLE productos (
    producto_id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    precio_unitario DECIMAL(10, 2) NOT NULL,
    costo_unitario DECIMAL(10, 2),          
    stock INT NOT NULL DEFAULT 0,
    stock_minimo INT NOT NULL DEFAULT 10,
    categoria VARCHAR(50),
    marca VARCHAR(50),
	proveedor_id INT,
    
    -- Definición de Clave Foránea
    FOREIGN KEY (proveedor_id) REFERENCES proveedores (proveedor_id)
);

CREATE TABLE ventas (
    venta_id INT PRIMARY KEY AUTO_INCREMENT,
    fecha DATETIME NOT NULL,               
    total DECIMAL(10, 2) NOT NULL,
    cliente_id INT,
    
    -- Definición de Clave Foránea
    FOREIGN KEY (cliente_id) REFERENCES clientes(cliente_id)
);

CREATE TABLE detalle_venta (
    detalle_id INT PRIMARY KEY AUTO_INCREMENT, 
    venta_id INT NOT NULL,
    producto_id INT NOT NULL,
    cantidad INT NOT NULL,
    precio_venta DECIMAL(10, 2) NOT NULL, -- Precio al momento de la venta

    -- Definición de Claves Foráneas
    FOREIGN KEY (venta_id) REFERENCES ventas(venta_id),
    FOREIGN KEY (producto_id) REFERENCES productos(producto_id)
);