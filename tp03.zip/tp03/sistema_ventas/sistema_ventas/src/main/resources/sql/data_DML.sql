INSERT INTO proveedores (nombre_proveedor, telefono) VALUES
('Mayorista TermoLux', '11-4555-1234'),    
('Artesanía del Mate Sur', '341-2345-6789'), 
('Accesorios Patagonia S.A.', '0294-889977'),
('Distribuidora Matera Norte', '387-556611'), 
('Importadora TechTemp', '11-7000-8000');   

INSERT INTO clientes (nombre, apellido, dni, cuit, direccion, telefono) VALUES
('Ana', 'Rodríguez', '30222111', '20302221117', 'Av. Central 123', '99-8877-6655'),   
('Carlos', 'López', '25444555', '20254445559', 'Calle Falsa 789', '99-1122-3344'),    
('Marta', 'García', '35777888', '27357778880', 'Ruta 3 Km 5', '99-5566-7788'),       
('Javier', 'Pérez', '28000111', '20280001112', 'Barrio Sur 45', '99-0099-1122'),       
('Sofía', 'Fernández', '32111000', '27321110005', 'Av. Rivadavia 500', '99-1010-2020'); 

INSERT INTO productos (nombre, precio_unitario, costo_unitario, stock, stock_minimo, categoria, marca, proveedor_id) VALUES
('Termo Acero 1.2L Negro', 25.00, 15.00, 50, 10, 'Termos', 'MarcaX', 1),           
('Mate Imperial Calabaza', 15.00, 8.00, 5, 10, 'Mates', 'MarcaSur', 2),           
('Bombilla Pico Loro Acero', 5.00, 2.00, 100, 20, 'Accesorios', 'MarcaAcc', 3),    
('Termo Media Manija 750ml', 18.00, 10.00, 15, 5, 'Termos', 'TechTemp', 5),       
('Yerba Mate Premium 500g', 8.00, 4.00, 2, 5, 'Yerbas', 'MateraNorte', 4);         

INSERT INTO ventas (venta_id, fecha, total, cliente_id) VALUES
(1, '2025-11-17', 45.00, 1), -- Venta 1: Ana (Termo, Mate, Bombilla)
(2, '2025-11-18', 25.00, 2), -- Venta 2: Carlos (Un Termo 1.2L)
(3, '2025-11-19', 36.00, 3), -- Venta 3: Marta (Dos Termos 750ml)
(4, '2025-11-19', 23.00, 4), -- Venta 4: Javier (Termo 750ml y Yerba)
(5, '2025-11-19', 10.00, 5); -- Venta 5: Sofía (Dos Yerbas Mate)

INSERT INTO detalle_venta (detalle_id, venta_id, producto_id, cantidad, precio_venta) VALUES
(1, 1, 1, 1, 25.00), 
(2, 1, 2, 1, 15.00), 
(3, 1, 3, 1, 5.00),  
(4, 2, 1, 1, 25.00), 
(5, 3, 4, 2, 18.00), -- 2 unidades del Termo 750ml
(6, 4, 4, 1, 18.00), 
(7, 4, 5, 1, 5.00),  
(8, 5, 5, 2, 5.00);  -- 2 unidades de Yerba Mate





