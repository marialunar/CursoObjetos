package ar.org.centro8.java.curso.tests;

import ar.org.centro8.java.curso.entidades.relaciones.Cuenta;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.Direccion;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.Empleado;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.Persona;

public class TestObjetosYCadenas {
    public static void main(String[] args) {
        /*
         * En Java existe la clase Class, internamente se toma a todas las clases que nosotros
         * creamos, como objetos de la clase Class en tiempo de ejecución.
         * Los atributos, son tratados en Java como objetos de la clase Field, que se encuentra
         * en el paquete java.lang.reflect.Field
         * Los métodos son tratados internamente por Java como objetos de la clase Method
         * que se encuentra en el paquete java.lang.reflect.Method
         * Aunque nosotros no creemos objetos de Field ni de Method directamente, el compilador
         * y la JVM generan estos objetos internamente para gestionar la información de nuestras
         * clases.
         * Las clases públicas de java.lang son accesibles de manera global
         */

        Direccion direccion1 = new Direccion("Av. Medrano", 162, "2", "8");
        Cuenta cuenta1 = new Cuenta(1, "Pesos argentinos");
        Persona persona1 = new Empleado("Mario", "Barakus", 90, direccion1, 100, 1_500_000);
        System.out.println(persona1);




    }
}
