package ar.org.centro8.java.curso.ejercicios.figuras.herencia;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Circulo extends Figura{
    private double radio;

    @Override
    public double getPerimetro(){
        return Math.PI * (radio * 2);
    }

    @Override
    public double getSuperficie(){
        return Math.PI * radio * radio;
    }
}
