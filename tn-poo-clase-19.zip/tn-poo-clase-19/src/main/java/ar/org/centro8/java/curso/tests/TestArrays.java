package ar.org.centro8.java.curso.tests;

import ar.org.centro8.java.curso.entidades.colecciones.Auto;

public class TestArrays {
    public static void main(String[] args) {
        System.out.println("Arrays, arreglos o vectores");

        /*
         * Un array es una estructura de datos en Java que permite almacenar múltiples valores
         * del mismo tipo de dato en una ubicación contínua de memoria.
         * Se utiliza cuando se necesita manejar un conjunto fijo de elementos relacionados.
         * Son inmutables, no se puede modificar su longitud.
         */

        /*
         * declaración:
         * tipoDeDato[] identificador; --> declaración
         * tipoDeDato identificador[]; --> declaración
         * identificador = new tipoDeDato[n]; --> cantidad de variables que va a tener
         */

        //creamos un arreglo de Auto
        Auto[] autos;
        //solo se pueden almacenar objetos del tipo Auto
        autos = new Auto[4];
        //la longitud del arreglo es de 4 elementos.

        //los arreglos, tienen un proceso de inicialización automático
        //los tipos de dato referenciados se inicializan en null
        for (int i = 0; i < autos.length; i++) {
            System.out.println(autos[i]);
        }

        //los tipos de datos numéricos se inicializan en 0
        int[] numeros = new int[4];
        for (int i = 0; i < autos.length; i++) {
            System.out.println(numeros[i]);
        }

        char[] caracteres = new char[4];
        for (int i = 0; i < caracteres.length; i++) {
            System.out.println(caracteres[i]);
        }
        //Java lo establece con su valor por defecto, que es el caracter nulo '\u0000'

        //asignación de valores
        autos[0] = new Auto("Fiat", "Palio", "Verde");
        // autos[1] = "Ford Taunus Rojo"; error, no se puede guardar otro tipo de dato que no sea un Auto
        autos[1] = new Auto("VolskWagen", "Gol", "Blanco");
        autos[2] = new Auto("Ranault", "Clio", "Amarillo");
        autos[3] = new Auto("Fiat", "Uno", "Negro");
        // autos[4] = new Auto("Ford", "Fiesta", "Violeta");
        //el anterior es un error que detiene el programa, no existe la posición 4 para una longitud de 4

        //mostrar el contenido de un arreglo
        System.out.println(autos); //no muestra el contenido
        //muestra el toString del arreglo, sin sobreescribir, es decir, su hashCode

        //para mostrar los elementos de un vector utilizamos la estructura for
        //esto genera un recorrido por índices
        for (int i = 0; i < autos.length; i++) {
            System.out.println(autos[i]);
        }
        //el for tradicional tiene ciertas desventajas, porque trasnfiere muchas responsabilidades
        //al programador, debe indicar el índice, la condición y el incremento.

        //A partir del JDK 5 aparece la estructura for-each
        //la palabra clave o estructura for-each no está definida como palabra clave del lenguaje
        //es el mismo for que se comporta como un for-each
        for(Auto auto:autos){
            System.out.println(auto);
        }

    }
}
