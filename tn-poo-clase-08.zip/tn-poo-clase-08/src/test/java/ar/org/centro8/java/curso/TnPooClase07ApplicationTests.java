package ar.org.centro8.java.curso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TnPooClase07ApplicationTests {

	@Test
	void contextLoads() {
	}

}
