package ar.org.centro8.java.curso.tests;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

import ar.org.centro8.java.curso.entidades.colecciones.Auto;

public class TestCollections {
    public static void main(String[] args) {
        /*
         * La interfaz List representa una lista con índices.
         * Es la única que tiene métodos con índices.
         * De esta interfaz, se pueden elegir distintas implementaciones con distintas tecnologías.
         * ArrayList es una lista del tipo vector, que tiene dentro un comportamiento que emula
         * a un Array, pero que no es un Array, ya que es completamente dinámico.
         * LinkedList tiene todo el comportamiento heredado de List, pero internamente, utiliza una
         * lista enlazada.
         * La clase Vector, implementa List, pero no son los vectores que hemos visto anteriormente.
         * Es una colección que internamente utiliza tecnología de vectores, pero que ha quedado en
         * desuso, es un lenguaje antiguo, con tecnología antigua, tiene una sincronización excesiva,
         * lo que la hace muy lento. Por eso se recomienda no utilizarla.
         * ArrayList es una lista del tipo Array y LinkedList es una lista enlazada.
         * ArrayList es más veloz para recorrer elementos.
         * LinkedList es más veloz para agregar y eliminar elementos.
         */

        //declaramos una variable del tipo de la interfaz para hacer polimorfismo
        List lista;

        lista = new ArrayList<>();
        lista = new LinkedList<>();
        lista = new Vector<>();

        // .add() método para agregar elementos a la lista
        lista.add(new Auto("Ford", "Focus", "Celeste fuego"));
        lista.add(new Auto("Peugeot", "308", "Gris perlado"));
        lista.add("Hola");
        lista.add(80);
        lista.add(23.45);
        //esta lista no tiene especificado un tipo de dato en particular
        //por lo tanto, será por defecto, del tipo Object, esto quiere decir que podrá guardar
        //cualquier tipo de dato.

        //recorrido de la lista con índices
        System.out.println("** Recorrido por índices **");
        for (int i = 0; i < lista.size(); i++) { //el método size() indica la longitud
            System.out.println(lista.get(i));
            //el método get() obtiene el elemento de la posición que se pasó como parámetro
        }

        // .remove() método para eliminar un elemento
        lista.remove(3); //elimina el elemento del índice 3

        //recorremos la lista con un for-each
        System.out.println("\n-- Recorrido con for-each --");
        for(Object o:lista) System.out.println(o);
        //el for-each funciona tanto con Arrays como con colecciones que implementen la interfaz Iterable
        //No sirve para agregar o eliminar elementos durante la iteración
        //No tiene acceso a los índices

        /*
         * Interfaz Iterable
         * Iterable es la interfaz padre de todas las interfaces del framework Collections.
         * Dentro de Iterable, se encuentra definido el método foreach(), es un método default.
         * Este método realiza un recorrido, facilita el recorrido de las colecciones sin utilizar
         * una estructura de repetición. Es la misma lista la que se autorecorre. Es una forma de
         * escribir código mucho más compacta, simple y moderna. Aparece a partir del JDK 8.
         */

        System.out.println("\n-- Recorrido con método foreach() --");

        lista.forEach(item -> System.out.println(item));
        /*
        el método foreach() recibe una expresión del tipo Consumer que define qué operación
        se ejecutará sobre cada elemento de la colección.
        Consumer es una interfaz funcional, cuyo propósito es "consumir" un valor (tiene un 
        único método abstracto). Representa una operación que recibe un argumento del tipo T y no
        devuelve nada. T es un tipo de dato genérico, no es un tipo concreto.
        Generalmente, se utilizan expresiones Lambdas.
        Las Lambda Expression son funciones anónimas que aparecieron a partir del JDK 8.
        Una función anónima es una porción de código (una función) que no tiene nombre y se define
        en el sitio en donde se va a utilizar.
        Se utilizan para simplificar código.
        En este caso, por cada elemento de la lista, voy a tener una variable llamada "item".
        No necesitamos indicar de qué tipo de dato es la lista.
        Luego va el operador flecha y la sentencia que se va a ejecutar por cada elemento.
        El operador flecha pertenece específicamente a las expresiones lambdas, separa los 
        parámetros del cuerpo de una función anónima.
        */

        System.out.println();

        //si quisiéramos definir más de una sentencia tenemos que utilizar un bloque de llaves
        lista.forEach(item -> {
            System.out.println(item);
            System.out.println("-");
        });

        // referencia de métodos (Method references)
        System.out.println("\n -- Recorrido con foreach() simplificado");
        lista.forEach(System.out::println);
        //con el operador de :: le estamos indicando que el ítem es implícito
        //y que lo coloque como argumento del método
        //es una sintaxis moderna, prolija y abreviada.

        System.out.println("\n** ListIterator **");
        /*
         * ListIterator es una interfaz especializada en recorrer colecciones que implementen List.
         * A diferencia del iterador simple (Iterator) o del método foreach() de Iterable, ListIterator
         * ofrece funcionalidades adicionales:
         * - recorrido bidireccional: permite avanzar y retroceder sobre las listas
         * - tiene acceso a índices
         * - permite eliminar, reemplazar y agregar elementos durante la ejecución.
         */

        List nombres = new ArrayList<>();
        nombres.add("Ricardo");
        nombres.add("Jenny");
        nombres.add("Carlos");
        nombres.add("Ana");
        nombres.add("Marcelo");
           
        //obtenemos el ListIterator
        ListIterator<String> li = nombres.listIterator();

        //recorrido hacia adelante
        System.out.println("\n-- recorrido hacia adelante --");
        while(li.hasNext()){ //determina si hay un elemento siguiente. 
            int indice = li.nextIndex(); //devuelve el índice del elemento que sigue
            String nombre = li.next(); //devuelve el siguiente elemento
            System.out.println("Índice " + indice + ": " + nombre);
        }
            
        //recorrido hacia atrás
        System.out.println("\n-- recorrido hacia atrás --");
        while(li.hasPrevious()){ //indica si hay un elemento antes 
            int indice = li.previousIndex(); //devuelve el índice previo
            String nombre = li.previous(); //devuelve el elemento anterior
            System.out.println("Índice " + indice + ": " + nombre);
        }

        //reemplazar elementos
        while(li.hasNext()){
            String nombre = li.next();
            if(nombre.equals("Carlos")) li.set("Carla"); //Reemplaza Carlos por Carla
        }
        System.out.println("\n Lista después de reemplazar a Carlos por Carla: " + nombres);

        //reinicio el ListIterator para que comience al principio nuevamente
        li = nombres.listIterator();

        //agregar elementos
        while(li.hasNext()){
            String nombre = li.next();
            if(nombre.equals("Ana")) li.add("Juan");
        }
        //agregamos el nombre de Juan después del de Ana.
        System.out.println("\nLista después de agregar a Juan luego de Ana: " + nombres);

        //reinicio la posición del cursor o puntero del ListIterator
        li = nombres.listIterator();

        //eliminar elementos
        while(li.hasNext()){
            String nombre = li.next();
            if(nombre.equals("Jenny")) li.remove(); //elimina el elemento actual ("Jenny")
        }

        System.out.println("Lista después de eliminar el elemento 'Jenny': " + nombres);

        System.out.println();

        /*
         * Uso de Generics
         * Hasta ahora la lista que creamos es del tipo Object. Porque no especificamos el tipo de
         * dato. Para especificar el tipo de dato de una lista, lo hacemos a través de los Generics.
         * Los Generics aparecieron a partir del JDK 5 y representan una característica que permite 
         * crear clases, interfaces o métodos con tipos de datos parametrizados.
         * Esto significa que podemos definir estructuras de datos y métodos que funcionan con 
         * cualquier tipo de datos, pero manteniendo la seguridad de los tipos en tiempo de compilación.
         * Los Generics permiten que una clase o método trabaje con diferentes tipos de datos sin tener
         * que escribir varias versiones del mismo código.
         */

        List<Auto> lista2 = new ArrayList<>();
        //no se pueden crear colecciones de tipos de datos primitivos
        //en su lugar debemos utilizar los wrappers
        //int -> Integer   double -> Double   float -> Float    char -> Character

        //al agregar un elemento a la lista, el editor nos indica el tipo de elemento que demos agregar
        lista2.add(new Auto("Renault", "Clío", "Rojo"));
        // lista2.add("Hola"); ERROR, no puedo agregar otro tipo de dato

        Auto auto1 = (Auto) lista.get(0);

        Auto auto2 = lista2.get(0);

        //copiar todos los autos de la lista a lista2
        /*
         * para copiar, tengo que tener en cuenta que no todos los elementos de lista, son autos.
         * Para eso, tengo que utilizar una estructura if con el operador instanceOf y castear.
         */

        lista.forEach(item -> {
            if(item instanceof Auto) lista2.add((Auto) item);
        });

        lista2.forEach(System.out::println);

        ////////////////////////////////////////////////////////////////////////////////////////
        
        System.out.println("\n** Interface Set **");
        /*
         * La interfaz Set implementa Collection y tiene 3 implementaciones.
         * La interfaz provee una lista sin índices. El mismo objeto contenido en la lista, funciona
         * como un índice. Por esto mismo, es que no admite valores duplicados.
         */

        // HashSet
        //La implementación HashSet es la más veloz de todas las implementaciones de Set

        //creamos una referencia a la interfaz
        Set<String> setSemana;

        setSemana = new HashSet<>();
        setSemana = new LinkedHashSet<>();
        setSemana = new TreeSet<>();

        //agregamos días de semana al Set
        setSemana.add("lunes");
        setSemana.add("lunes");
        setSemana.add("martes");
        setSemana.add("miércoles");
        setSemana.add("jueves");
        setSemana.add("jueves");
        setSemana.add("viernes");
        setSemana.add("sábado");
        setSemana.add("domingo");
        setSemana.add("domingo");

        //no se puede realizar un recorrido con for porque no tiene índices
        System.out.println("\n-- recorrido con foreach de setSemana --");
        setSemana.forEach(System.out::println);

        //HashSet no tiene un ordenamiento garantizado. Lo recorre de la manera más rápida posible.

        // LinkedHashSet
        /*
         * Es otra implementación se Set. Por lo tanto no tiene índices ni admite duplicados.
         * No es tan rápida como HashSet, aunque no lo vamos a notar en desarrollos chicos.
         * Almacena los elementos en una lista enlazada, con lo cual, cuando recorramos la lista,
         * vamos a ver los elementos por orden de entrada.
         */

        // TreeSet
        /*
         * La clase TreeSet implementa SortedSet que extiende de Set.
         * Al usar TreeSet, la clase del Generic debe implementar la interfaz Comparable.
         * TreeSet es una implementación que almacena en un árbol de orden natural.
         * Esto quiere decir, que los elementos van a aparecer ordenados, en este caso, como la
         * clase es String, el ordenamiento será alfabético. 
         * No necesitamos realizar un código de ordenamiento específico. 
         */
        
        //creamos un Set del tipo Auto
        Set<Auto> setDeAutos;

        // setDeAutos = new LinkedHashSet<>();
        setDeAutos = new TreeSet<>();

        //La clase Auto no implementa Comparable, por eso al ejecutar tenemos una Exception

        //Implementamos Comparable en la clase Auto para evitar la excepción.

        //agregamos los autos de lista2 al setDeAutos

        //con método foreach() y expresión Lambda
        // lista2.forEach(item -> setDeAutos.add(item));

        //con método foreach() y referencia de métodos
        // lista2.forEach(setDeAutos::add);

        //con método addAll() que está definido en la interfaz Collection
        setDeAutos.addAll(lista2); //recibe como parámetro otra colección.

        setDeAutos.add(new Auto("Chevrolet", "Corsa", "Rojo"));
        setDeAutos.add(new Auto("Chevrolet", "Corsa", "Rojo"));

        System.out.println("\n-- recorrido de setDeAutos --");
        setDeAutos.forEach(System.out::println);

        System.out.println("\n-- recorrido con hashCode() --");
        setDeAutos.forEach(auto -> System.out.println(auto + "\t" + auto.hashCode()));




    }
}
