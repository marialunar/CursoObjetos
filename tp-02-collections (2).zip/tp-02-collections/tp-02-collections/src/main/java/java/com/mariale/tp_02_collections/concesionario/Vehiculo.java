package java.com.mariale.tp_02_collections.concesionario;

import java.text.DecimalFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public abstract class Vehiculo implements Comparable <Vehiculo>{
    private String marca;
    private String modelo;
    private double precio;

    // Formato para el precio con dos decimales y separador de miles.
    private static final DecimalFormat formatoprecio = new DecimalFormat("$#,##0.00");

    public String getPrecioFormateado() {
        return formatoprecio.format(precio);
    }

    //Implementacion de interfaz Comparable<Vehiculo>
    @Override
    public int compareTo(Vehiculo v) {
        int comparaMarca = this.marca.compareTo(v.marca);
        if (comparaMarca != 0) return comparaMarca;
        int comparaModelo = this.modelo.compareTo(v.modelo);
        if (comparaModelo != 0) return comparaModelo;
        return Double.compare(this.precio, v.precio);
    }


}
