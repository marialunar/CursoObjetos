package java.com.mariale.tp_02_collections.concesionario;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class Moto extends Vehiculo {
    private String cilindrada;

    public Moto(String marca, String modelo, double precio, String cilindrada) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }

    @Override
    public String toString() {
        return String.format("Marca: %s // Modelo: %s // Cilindrada: %s // Precio: %s",
        getMarca(), getModelo(), cilindrada, getPrecioFormateado());
    }

}
