package ar.org.centro8.java.curso.tests;

import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.java.curso.entidades.colecciones.Persona;

public class TestApiStream {
    public static void main(String[] args) {
        //API Stream (Java 8)
        /*
         * Permite procesar flujos de datos de manera uniforme, independientemente de la fuente
         * de datos (archivo, BD, web service, etc.) utilizando un enfoque declarativo con expresiones
         * lambda.
         * API (Application Programming Interface) es un conjunto de métodos e interfaces que facilitan
         * el acceso a funcionalidades sin conocer su implementación interna.
         * Podemos decir que una API es como un conjunto de reglas y herramientas que permite que dos
         * programas se comuniquen entre sí.
         */

        //creamos una lista de Persona
        List<Persona> personas = new ArrayList<>();
        
        //agregamos elementos a la lista
        personas.add(new Persona(1, "Ana", 32));
        personas.add(new Persona(2, "Javier", 41));
        personas.add(new Persona(3, "Carlos", 22));
        personas.add(new Persona(4, "Estela", 55));
        personas.add(new Persona(5, "Raul", 27));
        personas.add(new Persona(6, "Miguel", 37));
        personas.add(new Persona(7, "Monica", 47));
        personas.add(new Persona(8, "Marcela", 57));
        personas.add(new Persona(9, "Ricardo", 67));
        personas.add(new Persona(10, "Juan", 45));
        personas.add(new Persona(11, "Juan", 23));

        //select * from personas;
        System.out.println("\nselect * from personas;");
        personas.forEach(System.out::println);

        //Stream provee métodos para filtrar
        //el método stream() devuelve una implementación de la interface Stream
        //el método filter() permite sobreescribir un predicado de expresión lambda
        //un predicado es una interface funcional que define una condición que un objeto determinado
        //debe cumplir.

        System.out.println("\n select * from personas where nombre='Ana';");
        personas
                .stream() //devuelve una secuencia de elementos para procesarlos (no guarda los elementos)
                .filter(p->p.getNombre().equals("Ana")) //obtenemos un objeto del tipo Persona, luego va la expresión booleana. Si arroja true, es parte de los resultados, si arroja false, no es parte de los resultados.
                .forEach(System.out::println); //filter devuelve un stream con todos los registros
                //con foreach() los recorremos.

        System.out.println("\n select * from personas where nombre='Ana' or nombre='Juan';");
        personas
                .stream()
                .filter(p->p.getNombre().equals("Ana") || p.getNombre().equals("Juan"))
                .forEach(System.out::println);

    }
}
